@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在启动 Dawa 激光器上位机调试版...
echo 调试版会保留控制台窗口，程序报错信息会显示在这里。
echo.
DawaLaserControlDebug.exe
set "exit_code=%errorlevel%"
echo.
if not "%exit_code%"=="0" echo 程序异常退出，错误代码：%exit_code%
echo 程序已经退出，按任意键关闭调试窗口。
pause >nul
exit /b %exit_code%
